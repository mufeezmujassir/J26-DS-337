# Component 1 figures and interpretation

## Figure 1 — Official attractions by tourism theme

The official catalogue is dominated by **Heritage** attractions (69 records), followed by **Scenic** attractions (52 records). This distribution shows that semantic retrieval must be combined with explicit category filtering; otherwise, large themes can dominate smaller themes such as Bliss, Thrills, or Festive. A zero value indicates that the taxonomy exists but no active official attraction currently carries that primary theme.

## Figure 2 — Geographic coverage

The 169-attraction catalogue is geographically imbalanced. **Ampara** contains the largest number of official records (51), while 5 districts currently contain no attraction mapped from the official catalogue. The chart should therefore be interpreted as catalogue coverage, not the true number of attractions in each district. District-level evaluation should report this imbalance because districts with few candidates cannot produce the same recommendation diversity as well-covered districts.

## Figure 3 — Daily Prophet test performance

Temperature is substantially more predictable than rainfall. On the untouched 2025 test set, minimum temperature achieved a mean MAE of **0.905°C**, while maximum temperature achieved **1.397°C**. Rainfall achieved a mean MAE of **5.537 mm/day** and RMSE of **13.763 mm/day**. The larger rainfall RMSE indicates that high-rainfall events produce much larger errors than ordinary days. Long-range rainfall forecasts should therefore be displayed with uncertainty and used as suitability evidence rather than guaranteed exact weather.

## Figure 4 — Rain-event classification

Across 25 districts, mean rain-event precision was **0.851**, recall was **0.579**, F1-score was **0.678**, and accuracy was **0.623**. Precision being higher than recall means that predicted rainy days are usually credible, but some actual rainy days remain undetected. This supports conservative explanations and indoor alternatives when rainfall risk is uncertain.

## Figure 5 — Galle historical seasonality

The Galle profile shows clear month-to-month variation. **February** has the highest multi-variable suitability score (0.840), while **November** has the highest historical mean rainfall (398.92 mm/month). Temperature comfort remains relatively stable, so rainfall and humidity explain most of the seasonal movement. This profile represents historical climatology and must not replace a live or date-specific daily forecast.

## Figure 6 — Chronological modelling split

The chronological split prevents future information from leaking into model training. Observations from 2010–2023 are used for fitting, 2024 is used for threshold selection and validation, and 2025 remains untouched until final evaluation. This produces a more realistic estimate of future forecasting performance than a random train-test split.

## Suggested placement in the report

- Place Figures 1 and 2 under **Attraction Dataset — Key Insights**.
- Place Figure 6 under **Feature Extraction / Model Preparation**.
- Place Figures 3 and 4 under **Weather Forecasting — Modelling and Results**.
- Place Figure 5 under **Historical Seasonality — Key Insights**.
